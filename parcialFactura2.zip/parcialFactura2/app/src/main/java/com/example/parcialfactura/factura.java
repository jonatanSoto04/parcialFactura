package com.example.parcialfactura;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class factura extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_factura);

        Button calcu = findViewById(R.id.pasar);

        TextView valor1 = findViewById(R.id.num1);
        TextView valor2 = findViewById(R.id.num2);

        TextView resul = findViewById(R.id.respuesta);
        Bundle recibeDatos = getIntent().getExtras();
        String info = recibeDatos.getString("keyDatos");

        resul.setText("Bienvenido " + info);

        calcu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String texto = valor1.getText().toString();
                int numero = Integer.parseInt(texto);
                String texto2 = valor2.getText().toString();
                int numero2 = Integer.parseInt(texto2);
                int tomate = 3000 * numero;
                int papa = 2500 * numero2;
                int factura = tomate + papa;
                resul.setText("El valor a pagar es: " + factura);
            }
        });

    }
}