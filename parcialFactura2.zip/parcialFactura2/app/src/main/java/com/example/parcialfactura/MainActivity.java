package com.example.parcialfactura;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView nombre = findViewById(R.id.nombre);
        TextView apellido = findViewById(R.id.apellido);
        Button pasar = findViewById(R.id.pasar);

        pasar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Bundle enviarDatos = new Bundle();
                enviarDatos.putString("keyDatos", nombre.getText().toString() + " " + apellido.getText().toString());

                Intent intent = new Intent(MainActivity.this, factura.class);
                intent.putExtras(enviarDatos);
                startActivity(intent);

            }
        });


    }
}